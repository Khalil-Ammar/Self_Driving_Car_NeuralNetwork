from PIL import Image
from string import digits
import os
import pickle
import random
import cv2 as cv
import numpy as np
import imutils


def get_average(set):
    return int(sum(set)/len(set))
CROP_PERCENTAGE = 0.75 #Percentage of the image to crop out.  0.8 -> bottom 20% of the image is kept.
def perspectiveTransform(img, heightScale, widthScale):
    #Function overview:
    #   1. Expand image width to reduce losses from original image after transform
    #   2. Compute transform homography
    #   3. Apply transform
    #   4. Return transformed image
    
    imgWidth = img.shape[1]
    imgHeight = img.shape[0]
    
    #Construct the indexes of a trapezoid as the homography:
    #0.2, 0.7
    #0.35, 0.26
    offset = imgWidth / 2
    initialPoints = np.float32([[int(widthScale * imgWidth), int(heightScale * imgHeight)],
                                [int((1 - widthScale) * imgWidth), int(heightScale * imgHeight)],
                                [0, imgHeight],
                                [imgWidth, imgHeight]])
    finalPoints = np.float32([[offset,  0],
                              [offset + imgWidth, 0],
                              [offset, imgHeight],
                              [offset + imgWidth, imgHeight]])
    M = cv.getPerspectiveTransform(initialPoints, finalPoints)
    iPT = cv.getPerspectiveTransform(finalPoints, initialPoints)
    warp = cv.warpPerspective(img, M, (2*imgWidth, imgHeight))
    
    return warp, iPT
#/PERSPECTIVE_TRANSFORM

def extract_data(img):
    im, _ = perspectiveTransform(img, 0.7, 0.125)
    gray_im = cv.cvtColor(np.float32(im), cv.COLOR_BGR2GRAY)
    gray_im = imutils.resize(gray_im, width=160)
    pixels_flat = gray_im.flatten()/255 ##flatten pixel values
    return pixels_flat

def create_data_file(out_file_name, data):
    fname = out_file_name
    outfile = open(fname, 'wb')
    pickle.dump(data, outfile)
    outfile.close()

if __name__ == "__main__":
    images_path = "./warped"
    data, _ = extract_data(images_path)

    ##shuffle and assign training and validation data
    train_data_fname = "train.pkl"
    valid_data_fname = "valid.pkl"
    random.shuffle(data)
    train_data_length = int(0.9*len(data)) ## choose training data as 75% of the dataset
    train_data = data[:train_data_length]
    valid_data = data[train_data_length:]


    ##convert data to .pkl format
    create_data_file(train_data_fname, train_data)
    create_data_file(valid_data_fname, valid_data)

    os.chdir("../")
