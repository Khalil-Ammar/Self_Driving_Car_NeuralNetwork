import cv2 as cv
import numpy as np

FILE_NAME = "stopsign1.avi"
cap = cv.VideoCapture(FILE_NAME)
if cap is None or not cap.isOpened():
	print("Unable to open video. Source: ", FILE_NAME)
	quit()
    
out = cv.VideoWriter("out.avi", cv.VideoWriter_fourcc(*"H264"), 30, (640, 480)) #Change "H264" to "MPEG" if this does not work
    
#Read until video is completed:
while(cap.isOpened()):
	ret, frame = cap.read()
	if ret == True:
		#Processing should happen in here.  Example: converting to HSV
		result = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
		
		out.write(result)
	else:
		break

cap.release()
out.release()
cv.destroyAllWindows		
