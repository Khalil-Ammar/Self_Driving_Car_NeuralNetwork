#File cropdata.py
#
#This file iterates over all data picture files in /CarProject/data/raw and crops out the bottom portion of the image.
#The cropped images are saved to /CarProject/data/cropped.

import glob
import numpy as np
import cv2 as cv
import os

###CONSTANTS
CROP_PERCENTAGE = 0.75 #Percentage of the image to crop out.  0.8 -> bottom 20% of the image is kept.
DATA_PATH = "/home/pi/Desktop/CarProject/data/"
RAW_DATA_PATH = DATA_PATH + "raw/"
CROPPED_DATA_PATH = DATA_PATH + "cropped/"
###/CONSTANTS

os.chdir(RAW_DATA_PATH)
for img in glob.glob("*.jpg"):
	raw = cv.imread(img)
	h, w, _ = raw.shape
	cropped = raw[int(CROP_PERCENTAGE*h):h, 0:w]
	path = CROPPED_DATA_PATH + img
	cv.imwrite(path, cropped)
