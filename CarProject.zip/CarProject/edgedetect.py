#File edgedetect.py
#
#This file implements lane recognition through the use of Canny edge detection and Hough Line transforms.

import cv2 as cv
import numpy as np
import math

###CONFIGURATION FLAGS
SHOW_PROCESSING_WINDOWS = True
###/CONFIGURATION FLAGS

###CONSTANTS
###/CONSTANTS

#CROP_FRAME
def cropFrame(img):
    #Function Overview:
    # 1.  Crop out the top CROP_PERCENTAGE percent of the image.
    # 2.  Return the cropped image
    CROP_PERCENTAGE = 0.75
    return img[int(CROP_PERCENTAGE*img.shape[0]):img.shape[0], 0:img.shape[1]]
#/CROP_FRAME

###EDGE_DETECT
def edgeDetect(frame):
    #Function Overview:
    # 1.  Extract cropped section of original frame
    # 2.  Convert to grayscale
    # 3.  Remove noise from image by applying gaussian blur
    # 4.  Perform edge detection on grayscale image
    # 4b.  Apply vertical filtering to reduce horizontal artifacts
    # 5.  Perform line fitting to filtered image
    # 6.  Extract slope from line
    # 7.  Compute drive direction from slope
    
    if SHOW_PROCESSING_WINDOWS:
        cv.imshow("Resized Frame", frame)
    
    # 1. Extract cropped section of the original frame:
    croppedFrame = cropFrame(frame)
    if SHOW_PROCESSING_WINDOWS:
        cv.imshow("Cropped Frame", croppedFrame)
    
    # 2. Convert to grayscale:
    grayFrame = cv.cvtColor(croppedFrame, cv.COLOR_BGR2GRAY)
    if SHOW_PROCESSING_WINDOWS:
        cv.imshow("Gray Frame", grayFrame)
        
    # 3. Remove noise from image by applying gaussian blur
    BLUR_KERNEL_SIZE = 5
    blurredFrame = cv.GaussianBlur(grayFrame, (BLUR_KERNEL_SIZE, BLUR_KERNEL_SIZE), 0)
        
    # 4. Perform edge detection on grayscale image:
    LOW_CANNY_THRESHOLD = 100
    HIGH_CANNY_THRESHOLD = 200
    SOBEL_KERNEL_SIZE = 3
    cannyFrame = cv.Canny(blurredFrame, LOW_CANNY_THRESHOLD, HIGH_CANNY_THRESHOLD, apertureSize=SOBEL_KERNEL_SIZE)
    if SHOW_PROCESSING_WINDOWS:
        cv.imshow("Canny Frame", cannyFrame)
    
    # 5. Perform line fitting to filtered image:
    HOUGH_THRESHOLD = 22
    lines = cv.HoughLines(cannyFrame, 1, np.pi/180, HOUGH_THRESHOLD, 0, 0)
    if lines is not None:
        for i in range(0, len(lines)):
            rho = lines[i][0][0]
            theta = lines[i][0][1]
            a = math.cos(theta)
            b = math.sin(theta)
            x0 = a*rho
            y0 = b*rho
            pt1 = (int(x0 + 1000*(-b)), int(y0 + 1000*(a)))
            pt2 = (int(x0 - 1000*(-b)), int(y0 - 1000*(a)))
            cv.line(croppedFrame, pt1, pt2, (0,0,255), 3)
            
    if SHOW_PROCESSING_WINDOWS:
        cv.imshow("Lines", croppedFrame)
    return 0, None
###/EDGE_DETECT
    
    
