
import cv2 as cv
import numpy as np
import numpy.polynomial.polynomial as poly
import cardriver as car
from time import sleep

###CONSTANTS
CAMERA_SOURCE = 0
###/CONSTANTS

###SETUP FUNCTIONS
def cameraSetup():
    cap = cv.VideoCapture(CAMERA_SOURCE)
    if cap is None or not cap.isOpened():
        print("Unable to open camera. Source: ", CAMERA_SOURCE)
        quit()
    return cap
    
def recordingSetup():
    out = cv.VideoWriter("out.avi", cv.VideoWriter_fourcc(*"H264"), 30, (160, 120))
    return out
###/SETUP FUNCTIONS

