#File main.py
#

#CUSTOM MODULES
import cardriver as car
import setup
import peakdetect as pd
import edgedetect as ed
#import neuralnet as nn
#import objectdetection as obj
#/CUSTOM MODULES

#MODULES
import cv2 as cv
import datetime
#/MODULES

###CONFIGURATION FLAGS
HARDWARE_ENABLE = False
RECORD_VIDEO = False
COLLECT_DATA = True
SHOW_RESULTS = True
###/CONFIGURATION FLAGS

###CONSTANTS
DATA_PATH = "/home/pi/Desktop/CarProject/data/raw/"
DRIVE_METHOD_OPTIONS = ["PEAK_DETECT", "EDGE_DETECT", "NEURAL_NET"]
DRIVE_METHOD = DRIVE_METHOD_OPTIONS[0]
IMG_RESCALE = 4
###/CONSTANTS

###MAIN LOOP:
def main():
    print("Program started.")
    cap = setup.cameraSetup()
    if RECORD_VIDEO:
        out = setup.recordingSetup()

    while True:
        #Read in frame from camera, resize to improve computation time:
        _, frame = cap.read()
        frame = cv.resize(frame, (int(frame.shape[1] / IMG_RESCALE), int(frame.shape[0] / IMG_RESCALE)), interpolation = cv.INTER_AREA)
        
        #Perform computations to determine driving direction:
        if DRIVE_METHOD == "PEAK_DETECT":
            direction, result = pd.peakDetect(frame)
        elif DRIVE_METHOD == "EDGE_DETECT":
            direction, result = ed.edgeDetect(frame)
        #elif DRIVE_METHOD == "NEURAL_NET":
            #direction, result = nn.neuralNet(frame)

        #Store results:
        if RECORD_VIDEO:
            out.write(result)
        if COLLECT_DATA:
            path = DATA_PATH + str(direction) + "___" + datetime.datetime.now().strftime("%Y-%m-%d %H-%M-%S-%f") + ".jpg" 
            cv.imwrite(path, frame)
        if SHOW_RESULTS:
            cv.imshow("Result", result)
            
        #Drive car:
        #if HARDWARE_ENABLE:
        #    car.drive(direction)
        
        #If the user presses the "ESC" key, close the program:
        k = cv.waitKey(1) & 0xFF
        if k == 27:
            cap.release()
            if RECORD_VIDEO:
                out.release()
            cv.destroyAllWindows()
            print("Program exiting.")
            quit()
main()
###/MAIN LOOP
