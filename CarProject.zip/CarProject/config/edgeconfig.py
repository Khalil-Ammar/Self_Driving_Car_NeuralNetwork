import cv2 as cv
import numpy as np
import math

#CAMERA_SETUP
CAMERA_SOURCE = 0
def cameraSetup():
    cap = cv.VideoCapture(CAMERA_SOURCE)
    if cap is None or not cap.isOpened():
        print("Unable to open camera. Source: ", CAMERA_SOURCE)
        quit()
    return cap
#/CAMERA_SETUP

#TRACKBAR_SETUP
def trackbarCall(x):
    pass
def trackbarSetup():
    cv.namedWindow("Trackbars")
    cv.createTrackbar("LC", "Trackbars", 100, 1000, trackbarCall)
    cv.createTrackbar("UC", "Trackbars", 200, 1000, trackbarCall)
    cv.createTrackbar("CKernel", "Trackbars", 1, 10, trackbarCall)
    cv.createTrackbar("BKernel", "Trackbars", 1, 10, trackbarCall)
    cv.createTrackbar("Hough", "Trackbars", 22, 30, trackbarCall)
#/TRACKBAR_SETUP
    
cap = cameraSetup()
trackbarSetup()
while True:
    _, frame = cap.read()
    IMG_RESCALE = 4
    CROP_PERCENTAGE = 0.75
    
    frame = cv.resize(frame, (int(frame.shape[1] / IMG_RESCALE), int(frame.shape[0] / IMG_RESCALE)), interpolation = cv.INTER_AREA)
    frame = frame[int(CROP_PERCENTAGE*frame.shape[0]):frame.shape[0], 0:frame.shape[1]]
    grayFrame = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    blurredFrame = cv.GaussianBlur(grayFrame, (2*cv.getTrackbarPos("BKernel", "Trackbars") + 1, 2*cv.getTrackbarPos("BKernel", "Trackbars") + 1), 0)
    cannyFrame = cv.Canny(blurredFrame, cv.getTrackbarPos("LC", "Trackbars"), cv.getTrackbarPos("UC", "Trackbars"), 2*cv.getTrackbarPos("CKernel", "Trackbars") + 1)
    HOUGH_THRESHOLD = cv.getTrackbarPos("Hough", "Trackbars")
    result = frame
    lines = cv.HoughLines(cannyFrame, 1, np.pi/180, HOUGH_THRESHOLD, 0, 0)
    if lines is not None:
        for i in range(0, len(lines)):
            rho = lines[i][0][0]
            theta = lines[i][0][1]
            a = math.cos(theta)
            b = math.sin(theta)
            x0 = a*rho
            y0 = b*rho
            pt1 = (int(x0 + 1000*(-b)), int(y0 + 1000*(a)))
            pt2 = (int(x0 - 1000*(-b)), int(y0 - 1000*(a)))
            cv.line(result, pt1, pt2, (0,0,255), 3)
    cv.imshow("frame", frame)
    cv.imshow("blurred", blurredFrame)
    cv.imshow("canny", cannyFrame)
    cv.imshow("result", result)
    
    k = cv.waitKey(5) & 0xFF
    if k == 27:
        cap.release()
        print("Program exiting.")
        quit()
